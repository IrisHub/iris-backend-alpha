import boto3

def event_handler(event, context):
	return ":)"