import json

with open('all_yummly.json', 'r+') as f:
	data = json.load(f)


for e in data:
	for ing in e['ingredientLines']:
		if 'beef' in ing.lower() or 'beef' in e['name'].lower():
			e['diet'] = 'none'

with open('all_yummly.json', 'r+') as f:
	f.seek(0)
	f.write(json.dumps(data, indent=4))
	f.truncate()